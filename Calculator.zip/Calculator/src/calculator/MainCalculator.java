package calculator;

public class MainCalculator {

	public static void main(String[] args) {
		
		Calc calc = new Calc();

	}

}
