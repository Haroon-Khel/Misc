package calculator;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

//The creation of the calculator UI
/*
 *  UI Needs:
 *  Jbuttons - One for each number 1 - 9. 1 for each of the 4 operations. 1 for Enter. 1 for a memory save button?
 *  1 for Clear.
 *  JTextField or JLabel
 *  JPanel
 *  JFrame, or let the class extend JFrame, whichever
 *  Include most of the 'Gui contruction methods' within the constructor
 *  
 */

public class Calc {

	private int one = 0;
	private int two = 0;
	private int function = 0;
	
	public Calc() {
		
		JFrame frame = new JFrame("Calculator");
		
		JPanel motherPanel = new JPanel();
		JPanel numberPanel = new JPanel();
		JPanel textFieldPanel = new JPanel();
		JPanel operationsPanel = new JPanel();
		
		JTextField textField = new JTextField("0");
		
		JButton[] jButtons = new JButton[10];
		JButton add = new JButton("+");
		JButton sub = new JButton("-");
		JButton divide = new JButton("/");
		JButton mult = new JButton("x");
		JButton enter = new JButton("=");
		JButton clear = new JButton("Clear");
		JButton memory = new JButton("Memory");
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		frame.setSize(400, 400);
		
		//All things TextField related
		textField.setBackground(Color.WHITE);
		textField.setPreferredSize(new Dimension(300, 40));
		textField.setEnabled(false);
		textField.setHorizontalAlignment(4);
		textField.setDisabledTextColor(Color.BLACK);
		
		textFieldPanel.setPreferredSize(new Dimension(300, 40));
		textFieldPanel.add(textField);
		
		frame.add(motherPanel);
		motherPanel.add(textFieldPanel);
		
		//All things NumberButtons related
		NumberAction[] numberActions = new NumberAction[10];
		for (int i=9;i>=0;i--) {
			jButtons[i] = new JButton(Integer.toString(i));
			numberPanel.add(jButtons[i]);
			numberActions[i] = new NumberAction(jButtons[i], textField);
			jButtons[i].addActionListener(numberActions[i]);
		}
		
		numberPanel.setPreferredSize(new Dimension(150, 150));
		motherPanel.add(numberPanel);
		
		//All things OperationButtons related
		operationsPanel.setPreferredSize(new Dimension(300,100));
		operationsPanel.add(add);
		operationsPanel.add(sub);
		operationsPanel.add(divide);
		operationsPanel.add(mult);
		operationsPanel.add(clear);
		operationsPanel.add(memory);
		operationsPanel.add(enter);
		
		motherPanel.add(operationsPanel);
		
		AddAction addAction = new AddAction(textField);
		add.addActionListener(addAction);
		MultiplyAction multAction = new MultiplyAction(textField);
		mult.addActionListener(multAction);
		SubtractAction subAction = new SubtractAction(textField);
		sub.addActionListener(subAction);
		DivideAction divAction = new DivideAction(textField);
		divide.addActionListener(divAction);
		EnterAction entAction = new EnterAction(textField);
		enter.addActionListener(entAction);
		ClearAction clearAction = new ClearAction(textField);
		clear.addActionListener(clearAction);
		
		
		
	}



	private class NumberAction implements ActionListener {
		
		String c;
		JTextField textField;
		
		public NumberAction(JButton button, JTextField textField) {
			this.c = button.getText();
			this.textField = textField;
		}
		
		@Override
		public void actionPerformed(ActionEvent e) {
			if (textField.getText().equals("0")) {
				textField.setText(c);
			} else {
				textField.setText(textField.getText() + c);
			}
		}
	}
	
	private class AddAction implements ActionListener {
		
		JTextField textField;
		
		public AddAction(JTextField textField) {
			this.textField = textField;
		}
		
		@Override
		public void actionPerformed(ActionEvent e) {
			one = Integer.parseInt(textField.getText());
			textField.setText("");
			function = 1;
		}
		
	}
	
	private class MultiplyAction implements ActionListener {
		
		JTextField textField;
		
		public MultiplyAction(JTextField textField) {
			this.textField = textField;
		}
		
		@Override
		public void actionPerformed(ActionEvent e) {
			one = Integer.parseInt(textField.getText());
			textField.setText("");
			function = 2;
		}
	}
	
	private class SubtractAction implements ActionListener {

		JTextField textField;
		
		public SubtractAction(JTextField textField) {
			this.textField = textField;
		}
		
		@Override
		public void actionPerformed(ActionEvent e) {
			one = Integer.parseInt(textField.getText());
			textField.setText("");
			function = 3;
		}
	}
	
	private class DivideAction implements ActionListener {
		
		JTextField textField;
		
		public DivideAction(JTextField textField) {
			this.textField = textField;
		}
		
		@Override
		public void actionPerformed(ActionEvent e) {
			one = Integer.parseInt(textField.getText());
			textField.setText("");
			function = 4;
		}
	}
	
	private class EnterAction implements ActionListener {
		
		JTextField textField;
		
		public EnterAction(JTextField textField) {
			this.textField = textField;
		}
		
		@Override
		public void actionPerformed(ActionEvent e) {
			two = Integer.parseInt(textField.getText());
			if (function == 1) {
				textField.setText(Integer.toString(one+two));
			}
			if (function == 2) {
				textField.setText(Integer.toString(one*two));
			}
			if (function == 3) {
				textField.setText(Integer.toString(one-two));
			}
			if (function == 4) {
				textField.setText(Integer.toString(one/two));
			}
		}
		
	}
	
	private class ClearAction implements ActionListener {
		
		JTextField textField;
		
		public ClearAction(JTextField textField) {
			this.textField = textField;
		}
		
		@Override
		public void actionPerformed(ActionEvent e) {
			textField.setText("0");
			function = 0;
		}
		
	}
}


/*
 * Backspace button, memory, digit limit.
 */


