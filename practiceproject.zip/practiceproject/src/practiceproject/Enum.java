package practiceproject;

public enum Enum {
	
	book1("booktitle1", "date1"),
	book2("booktitle2", "date2"),
	book3("booktitle3", "date3"),
	book4("booktitle4", "date4");
	
	private final String bookTitle;
	private final String date;
	
	Enum(String bookTitle, String date) {
		this.bookTitle = bookTitle;
		this.date = date;
	}
	
	public String getBookTitle() {
		return bookTitle;
	}
	
	public String getDate( ) {
		return date;
	}

}
