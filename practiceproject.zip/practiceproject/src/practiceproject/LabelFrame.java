package practiceproject;
import java.awt.FlowLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.Icon;
import javax.swing.ImageIcon;

public class LabelFrame extends JFrame {
	
	private final JLabel label1;
	private final JLabel label2;
	private final JLabel label3;
	
	//LabelFrame constructor adds JLabels to JFrame
	public LabelFrame() {
		// Constructor of superclass takes in a String, which it sets as the title of the window, hence:
		super("Testing JLabel");
		setLayout(new FlowLayout()); //Set frame layout
		
		//JLabel constructor with a string argument
		label1 = new JLabel("Label with text");
		label1.setToolTipText("This is Label 1");
		add(label1); //Adds label1 to Jframe
		
		//JLabel constructor with String, icon and alignment argument
		Icon cena = new ImageIcon(getClass().getResource("hariottttttttttt.png"));
		label2 = new JLabel("This is Label 2", cena, SwingConstants.LEFT);
		label2.setToolTipText("This is Label 2");
		add(label2);//Adds label2 to JFrame
		
		//JLabel constructor with no arguments
		label3 = new JLabel();
		label3.setText("Label with icon and text at the botton");
		label3.setIcon(cena);
		label3.setHorizontalTextPosition(SwingConstants.CENTER);
		label3.setVerticalTextPosition(SwingConstants.BOTTOM);
		add(label3);//Adds label3 to Jframe
	}

}
