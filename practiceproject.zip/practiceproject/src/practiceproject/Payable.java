package practiceproject;

public interface Payable {
	double getPaymentAmount();
}
