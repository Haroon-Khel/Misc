package practiceproject;

public class StringWhatever {
	
	private String[] strings = new String[4];
	private String string1;
	private String string2;
	private String string3;
	private String string4;
	
	public StringWhatever(String string1, String string2, String string3, String string4) {
		
		this.strings[0] = string1;
		this.strings[1] = string2;
		this.strings[2] = string3;
		this.strings[3] = string4;
			
	}
	
	public void getSt() {		
		for (String string : strings) {			
			if (string.startsWith("st")) {				
				System.out.println(string);				
			}			
		}	
	}
	
	public void getAn() {
		for (String string : strings) {
			if (string.startsWith("an")) {
				System.out.println(string);
			}
		}
	}

}
