package practiceproject;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;

public class RadioButton extends JFrame {

	private JTextField textfield;
	private Font plainFont;
	private Font boldFont;
	private Font italicFont;
	private Font boldItalicFont;
	private JRadioButton plainbutton;
	private JRadioButton boldbutton;
	private JRadioButton italicbutton;
	private JRadioButton bolditalicbutton;
	private ButtonGroup radioGroup;
	
	public RadioButton() {
		
		super("RadioButton Test");
		setLayout(new FlowLayout());
		
		textfield = new JTextField("Notice the change in font style", 25);
		add(textfield);
		
		plainbutton = new JRadioButton("Plain", true); // The second argument indicates that the Plai button will be the first default selection
		boldbutton = new JRadioButton("Bold", false);
		italicbutton = new JRadioButton("Italic", false);
		bolditalicbutton = new JRadioButton("Bold + Italic", false);
		add(plainbutton);
		add(boldbutton);
		add(italicbutton);
		add(bolditalicbutton);
		
		//Adding each button to one radio group ensures that only one can be selected
		radioGroup = new ButtonGroup();
		radioGroup.add(plainbutton);
		radioGroup.add(boldbutton);
		radioGroup.add(italicbutton);
		radioGroup.add(bolditalicbutton);
		
		plainFont = new Font("Serif", Font.PLAIN,14);
		boldFont = new Font("Serif", Font.BOLD, 14);
		italicFont = new Font("Serif", Font.ITALIC, 14);
		boldItalicFont = new Font("Serif", Font.BOLD + Font.ITALIC, 14);
		textfield.setFont(plainFont);
		
		//Register events for JRadioButtons
		plainbutton.addItemListener(new RadioButtonHandler(plainFont));
		boldbutton.addItemListener(new RadioButtonHandler(boldFont));
		italicbutton.addItemListener(new RadioButtonHandler(italicFont));
		bolditalicbutton.addItemListener(new RadioButtonHandler(boldItalicFont));		
		
	}
	
	private class RadioButtonHandler implements ItemListener {
		
		private Font font;
		
		public RadioButtonHandler(Font f) {
			font = f;
		}
		@Override
		public void itemStateChanged(ItemEvent event) {
			
			textfield.setFont(font);
			
		}
		
	}
	
}
