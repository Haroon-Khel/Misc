package practiceproject;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;


public class ButtonFrame extends JFrame {

	 private final JButton plainButton;
	 private final JButton fancyButton;
	 
	 public ButtonFrame() {
		 
		 super("Testing Buttons");
		 setLayout(new FlowLayout());
		 
		 plainButton = new JButton("Plain Button");
		 add(plainButton);
		 
		 Icon image1 = new ImageIcon(getClass().getResource("Firefox_wallpaper.png"));
		 Icon image2 = new ImageIcon(getClass().getResource("hariottttttttttt.png"));
		 
		 fancyButton = new JButton("Fancy Button", image1);
		 fancyButton.setRolloverIcon(image2);
		 add(fancyButton);
		 
		 ButtonHandler handler = new ButtonHandler(); //Implementing the event handler class, ButtonHandler, as the event handler to the Jbuttons
		 fancyButton.addActionListener(handler);
		 plainButton.addActionListener(handler);
		  
	 }
	 
	 //Action Listener class
	 
	 private class ButtonHandler implements ActionListener {
		 
		 //handle button event
		 @Override
		 public void actionPerformed(ActionEvent event) {
			 JOptionPane.showMessageDialog(ButtonFrame.this, String.format("You pressed: %s",
					 event.getActionCommand()));
		 }
		 
	 }
	
}














