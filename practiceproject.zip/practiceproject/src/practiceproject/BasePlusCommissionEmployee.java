package practiceproject;

public class BasePlusCommissionEmployee extends CommissionEmployee{

	private double baseSalary;
	
	public BasePlusCommissionEmployee(String firstName, String lastName, String socialSecurityNumber, 
			double grossSales, double commissionRate, double baseSalary) {
		
		super(firstName, lastName, socialSecurityNumber, commissionRate, grossSales);
		
		if (baseSalary < 0.0) {
			throw new IllegalArgumentException("Base Salary must be > 0");
		}
		
		this.setBaseSalary(baseSalary);
	}

	public double getBaseSalary() {
		return baseSalary;
	}

	public void setBaseSalary(double baseSalary) {
		if (baseSalary < 0.0) {
			throw new IllegalArgumentException("Base Salary must be > 0");
		}
		this.baseSalary = baseSalary;
	}
	
	@Override
	public double getEarnings() {
		return baseSalary + super.getEarnings(); // Overrides the abstract method getEarnings created in Account
	}
	
	@Override
	public String toString() {
		
		return String.format("%s: %s %s%n%s: %s%n%s: %.2f%n%s: %.2f%n%s: %.2f%n", "Employee name", firstName, lastName,
				"Social Security Number", socialSecurityNumber, "Gross Sales", grossSales, "Commission rate", commissionRate, 
				"Base Salary", baseSalary);
	
	}
	
}
