package practiceproject;

public class HourlyEmployee extends Account{
	
	private double wage;
	private double hours;
	
	public HourlyEmployee(String firstName, String lastName, String socialSecurityNumber, double wage, double hours) {
		
		super(firstName, lastName, socialSecurityNumber);
		
		if (wage < 0.0) {
			throw new IllegalArgumentException("Wage must be >= 0");
		}
		
		if (hours < 0.0 || hours > 168.0) {
			throw new IllegalArgumentException("Hours must be within 0 and 168 (exclusive");
		}
		
		this.setWage(wage);
		this.setHours(hours);
	}

	public double getHours() {
		return hours;
	}

	public void setHours(double hours) {
		
		if (hours < 0.0 || hours > 168.0) {
			throw new IllegalArgumentException("Hours must be within 0 and 168 (exclusive");
		}
		this.hours = hours;
	}

	public double getWage() {
		return wage;
	}

	public void setWage(double wage) {
		
		if (wage < 0.0) {
			throw new IllegalArgumentException("Wage must be >= 0");
		}
		this.wage = wage;
	}
	
	@Override
	public double getEarnings() {
		if (hours <= 40) {
			return wage * hours;
		} else {
			return (40 + (hours - 40) * 1.5) * wage;
		}
	}
	
	@Override // Redefining an existing method from the Object superclass 
	public String toString() {
		
		return String.format("%s: %s %s%n%s: %s%n%s: %.2f%n%s: %.2f%n", "Employee name", firstName, lastName,
				"Social Security Number", socialSecurityNumber, "Hours", hours, "Wage", wage);
	
	}
	
}
