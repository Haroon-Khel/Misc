package practiceproject;

public abstract class Account implements Payable{
	
	protected final String firstName;
	protected final String lastName;
	protected final String socialSecurityNumber;
	
	public Account(String firstName, String lastName, String socialSecurityNumber) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.socialSecurityNumber = socialSecurityNumber;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public String getSocialSecurityNumber() {
		return socialSecurityNumber;
	}
	
	@Override // Redefining an existing method from the Object superclass 
	public String toString() {
		
		return String.format("%s: %s %s%n%s: %s%n", "Employee name", firstName, lastName,
				"Social Security Number", socialSecurityNumber);
	}
	
	public abstract double getEarnings(); // Creates an abstract method, for inherited classes to build upon
	
	
	
	
	
	
	
}
