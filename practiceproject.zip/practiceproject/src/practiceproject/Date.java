package practiceproject;

public class Date extends Account {
	
	private double weeklySalary;
	
	public Date(String firstName, String lastName, String socialSecurityNumber, double weeklySalary) {
		
		super(firstName, lastName, socialSecurityNumber);
		
		if (weeklySalary < 0.0) {
			throw new IllegalArgumentException("Weekly Salary must be >= 0.0");
		}
		
		this.setWeeklySalary(weeklySalary);
		
	}
	
	public double getWeeklySalary() {
		return weeklySalary;
	}

	public void setWeeklySalary(double weeklySalary) {
		
		if (weeklySalary < 0.0) {
			throw new IllegalArgumentException("Weekly Salary must be >= 0.0");
		}
		this.weeklySalary = weeklySalary;
	}
	
	@Override
	public double getEarnings() {
		return weeklySalary;
	}
	
	@Override // Redefining an existing method from the Object superclass 
	public String toString() {
		
		return String.format("%s: %s %s%n%s: %s%n%s: %.2f%n", "Employee name", firstName, lastName,
				"Social Security Number", socialSecurityNumber,
				"Weekly Salary", weeklySalary);
	}

	@Override
	public double getPaymentAmount() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
	
	
	
	
	
	
	
}
