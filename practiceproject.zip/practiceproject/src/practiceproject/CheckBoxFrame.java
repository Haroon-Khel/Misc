package practiceproject;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JCheckBox;

public class CheckBoxFrame extends JFrame {
	
	private final JTextField textfield;
	private final JCheckBox boldcheckbox;
	private final JCheckBox italiccheckbox;
	
	//Constructor to add checkboxes to JFrame
	public CheckBoxFrame() {
		
		super("JCheckBox Test");
		setLayout(new FlowLayout());
		
		//Set up JTextfield
		textfield = new JTextField("Watch the font style change", 20);
		textfield.setFont(new Font("Serif", Font.PLAIN, 14));
		add(textfield);
		
		//Set up JCheckBoxes
		boldcheckbox = new JCheckBox("Bold");
		italiccheckbox = new JCheckBox("Italic");
		add(boldcheckbox);
		add(italiccheckbox);
		
		//Give checkboxes listeners
		CheckBoxHandler handler = new CheckBoxHandler();
		boldcheckbox.addItemListener(handler);
		italiccheckbox.addItemListener(handler);
		
	}
	
	//CheckBoxHandler class
	private class CheckBoxHandler implements ItemListener {
		
		@Override
		public void itemStateChanged(ItemEvent event) {
			
			Font font = null;
			
			//If statements to determine which checkboxes are checked
			if (boldcheckbox.isSelected() && italiccheckbox.isSelected()) {
				font = new Font("Serif", Font.BOLD + Font.ITALIC, 14);
			}
			else if (boldcheckbox.isSelected()) {
				font = new Font("Serif", Font.BOLD, 14);
			}
			else if (italiccheckbox.isSelected()) {
				font = new Font("Serif", Font.ITALIC, 14);
			}
			else {
				font = new Font("Serif", Font.PLAIN, 14);
			}
			textfield.setFont(font); //Modify the font of the text box
		}
		
	}
	
}








