package practiceproject;
import java.awt.FlowLayout;
import java.awt.Color;
import javax.swing.JList;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.ListSelectionModel;

public class ListFrame extends JFrame{
	
	private final JList<String> colourJList;
	private static final String[] colourNames = {"Black", "Blue", "Cyan", "Dark Grey", "Gray", "Green", "Light Gray", "Magenta", 
		"Orange", "Pink", "Red", "White", "Yellow"}; //List which contains text
	private static final Color[] colors = {
			Color.BLACK, Color.BLUE, Color.CYAN, Color.DARK_GRAY, Color.GRAY, Color.GREEN, Color.LIGHT_GRAY, Color.MAGENTA,
			Color.ORANGE, Color.PINK, Color.RED, Color.WHITE, Color.YELLOW};
	
	public ListFrame() {
		
		super("JList test");
		setLayout(new FlowLayout());
		
		colourJList =  new JList<String>(colourNames);
		colourJList.setVisibleRowCount(5);//5 visible at a time
		colourJList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); //Options can be selected one at a time
		
		add(new JScrollPane(colourJList)); //Add JScrollPane containing list to JFrame
		
		colourJList.addListSelectionListener(
				new ListSelectionListener() {//Anonymous inner class
					
					@Override
					public void valueChanged(ListSelectionEvent event) {
						getContentPane().setBackground(
								colors[colourJList.getSelectedIndex()]);
					}
					
				});
		
	}

}


//ListFrame listFrame = new ListFrame();
//listFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//listFrame.setSize(350, 100);
//listFrame.setVisible(true);