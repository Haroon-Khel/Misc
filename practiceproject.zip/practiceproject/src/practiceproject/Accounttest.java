package practiceproject;
import javax.swing.JFrame;

public class Accounttest {

	public static void main(String[] args) {
		
		StringWhatever word = new StringWhatever("string", "hello", "anotherstring", "andanotherstring");
		word.getSt();
		word.getAn();
		
	}
}
