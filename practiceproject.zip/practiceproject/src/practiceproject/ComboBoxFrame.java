package practiceproject;

import java.awt.FlowLayout;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.Icon;
import javax.swing.ImageIcon;


public class ComboBoxFrame extends JFrame {
	
	private final JComboBox<String> imagesJComboBox; //Hold Icon names
	private final JLabel label; //Displays selected Icon
	
	//Array of the images, makes it easier for use in Icon array
	private static final String[] names = {"Firefox_wallpaper.png", "hariottttttttttt.png", "Timett.jpg"};
	
	//Icon array
	private final Icon[] icons = {
			new ImageIcon(getClass().getResource(names[0])),
			new ImageIcon(getClass().getResource(names[1])),
			new ImageIcon(getClass().getResource(names[2])),
	};
	
	//Constructor
	public ComboBoxFrame() {
		
		super("Testing JComboBox");
		setLayout(new FlowLayout());
		
		imagesJComboBox = new JComboBox<String>(names); //Set up JComboBox
		imagesJComboBox.setMaximumRowCount(3); //Displays 2 rows at a time, thus will implement a scroll bar
		
		imagesJComboBox.addItemListener(
				new ItemListener() { //Anonymous inner class
					@Override
					public void itemStateChanged(ItemEvent event) { 
						//Determine whether item is selected
						if (event.getStateChange() == ItemEvent.SELECTED) {
							label.setIcon(icons[imagesJComboBox.getSelectedIndex()]);
						}
						
					}
				}//End anonymous class
				); //End addItemListener
		add(imagesJComboBox);
		label = new JLabel(icons[0]); //Display default icon
		add(label);
	} //End Constructor
	
}
