package main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Formatter;
import java.util.LinkedList;
import java.util.Scanner;

public class Main {
	
	private static Formatter file;
	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		
		//createFile("file1.csv");
		MenuOption();
	}
	
	private static void MenuOption() {
		//Method to collect menu option
		System.out.println("\nEnter menu number:");
		System.out.printf("%s%n%s%n%s%n%s%n%s%n", "1 - New Contact", "2 - Edit Contact","3 - Delete Contact",
				"4 - Show Contacts", "5 - Terminate");
		int choice = scanner.nextInt();
		MenuChoice(choice);
		
	}
	
	private static void MenuChoice(int choice) {
		
		if (choice == 1) {
			newContact();
		} else if (choice == 2) {
			editContact();
		} else if (choice == 3) {
			deleteContact();
		} else if (choice == 4) {
			displayContact();
		} else if (choice == 5) {
			System.out.println("\nGoodbye!");
			System.exit(1);
		}
		
	}
	
	//Option 1
	private static void newContact() {
		
		System.out.printf("%n%s%n", "Enter new contact first name: ");
		String firstName = scanner.next();
		
		System.out.printf("%n%s%n", "Enter new contact last name: ");
		String lastName = scanner.next();
		
		System.out.printf("%n%s%n", "Enter new contact number");
		String Number = scanner.next();
		
		Contact contact = new Contact(firstName, lastName, Number);
		System.out.printf("%n%s%n%n%s%n", "New Contact", contact);
		
		//Add new contact to address book
		try {
			
//			String count = Integer.toString(contact.getCount());
			FileWriter fw = new FileWriter("file1.csv", true);
			BufferedWriter bw = new BufferedWriter(fw);
			int counter = counter();
			StringBuilder sb = new StringBuilder();
			sb.append(Integer.toString(counter));
			sb.append(" ");
			sb.append(firstName);
			sb.append(" ");
			sb.append(lastName);
			sb.append(" ");
			sb.append(Number);
			sb.append("\n");
			bw.write(sb.toString());
			bw.close();
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		MenuOption();
		
	}
	
	private static void createFile(String fileName) {
		
		try {
			file = new Formatter(fileName);
		}
		
		catch(FileNotFoundException e) {
			System.err.println("Error opening the file. Terminating");
			System.exit(1);
		}
		
	}
	
	//Option 4
	private static void displayContact() {
		Scanner scan = new Scanner(System.in);
		System.out.printf("%nAll or a particular letter?%n");
		String pick = scan.next();
				
		if (pick.equalsIgnoreCase("all")) {
			
			try {
			FileReader fr = new FileReader("file1.csv");
			
			BufferedReader br = new BufferedReader(fr);
			Scanner read = new Scanner(br);
			
			System.out.printf("%-5s %-10s %-10s %-10s%n%n", "Entry", "Forename","Surname", "Number");
			
			while (read.hasNext()) {
				int count = read.nextInt();
				String firstName = read.next();
				String lastName = read.next();
				String number = read.next();
				System.out.printf("%-5s %-10s %-10s %-10s%n", count, firstName, lastName, number);
				//Input the line as a string. Split it into 3. Printf for better format
			}
			
			br.close();
			
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else if (alphabet(pick)) {
			try {
				
				FileReader fr = new FileReader("file1.csv");
				
				BufferedReader br = new BufferedReader(fr);
				Scanner read = new Scanner(br);
				
				System.out.printf("%-5s %-10s %-10s %-10s%n%n", "Entry", "Forename","Surname", "Number");
				
				while (read.hasNext()) {
					char p = pick.charAt(0);
					int count = read.nextInt();
					String firstName = read.next();
					String lastName = read.next();
					String number = read.next();
					char letter = firstName.charAt(0);
					if (letter == Character.toLowerCase(p) || letter == Character.toUpperCase(p)) {
						System.out.printf("%-5s %-10s %-10s %-10s%n", count, firstName, lastName, number);
					}
				}
				
				read.close();
				fr.close();
				br.close();
				
			}
			
			catch (IOException e) {
				e.printStackTrace();
			}
			
		}
		
		System.out.println();
		MenuOption();
	}
	
	//Sub Method, for any method that requires a contact search
	private static boolean alphabet(String pick) {
		boolean bool = false;
		
		String[] alphabet = {"a","b","c","d","e","f",
				"g","h","i","j","k","l","m","n","o",
				"p","q","r","s","t","u","v","w","x",
				"y","z"};

		for (String letter : alphabet) {
			if (pick.equalsIgnoreCase(letter)) {
				bool = true;
				break;
			}
		}
		return bool;
	}
	
	private static void deleteContact() {
		
		if (counter() > 1) {
			
			System.out.printf("%n%s%n%s%n", "Search for your contact", "Enter All or a particular letter:");
			String pick = scanner.next();
			
			try {
				
				FileReader fr = new FileReader("file1.csv");
				BufferedReader br = new BufferedReader(fr);
				Scanner read = new Scanner(br);
				
				FileReader fr2 = new FileReader("file1.csv");
				BufferedReader br2 = new BufferedReader(fr2);
				Scanner read2 = new Scanner(br2);
				
				if (counter() > 1) {
					//All
					if (pick.equalsIgnoreCase("all")) {
					
						while (read.hasNext()) {
							int count = read.nextInt();
							String firstName = read.next();
							String lastName = read.next();
							String number = read.next();
							System.out.printf("%-5s %-10s %-10s %-10s%n", count, firstName, lastName, number);
						}	
					}
					//Particular Letter
					else if (alphabet(pick)) {
					
						while (read.hasNext()) {
							char p = pick.charAt(0);
							int count = read.nextInt();
							String firstName = read.next();
							String lastName = read.next();
							String number = read.next();
							char letter = firstName.charAt(0);
							if (letter == Character.toLowerCase(p) || letter == Character.toUpperCase(p)) {
								System.out.printf("%-5s %-10s %-10s %-10s%n", count, firstName, lastName, number);
							}
						}
					}
					
					System.out.printf("%n%s%n", "Select the number of the contact that you wish to delete:");
					String entry = scanner.next();
					
					//Finding the contact again
					while(read2.hasNext()) {
						
						String count = read2.next();
						String firstName = read2.next();
						String lastName = read2.next();
						String number = read2.next();
						
						if (entry.equals(count)) {
							
							System.out.printf("%n%s%n%n%-5s %-5s %-5s%n%n%s%n%s%n", "Are you sure you want to delete this contact?:", firstName, 
									lastName, number, "1 - Delete", "2 - Return to menu");
							String ask1 = scanner.next();
							//Edit
							if (ask1.equals("1")) {
								int entryInt = Integer.parseInt(entry);
								StringBuilder build = new StringBuilder();
								LinkedList<String> list = entriesToString();
								list.remove(entryInt -1);
								
								for (int i = entryInt -1;i<list.size();i++) {
									
									String[] listEntry = list.get(i).split(" ");
									listEntry[0] = String.valueOf(i+1);
									String correctEntry = listEntry[0] + " " + listEntry[1] + " " + listEntry[2] + " " + listEntry[3];
									list.remove(i);
									list.add(i, correctEntry);
									
								}
								
								for (String link : list) {
									
									build.append(link);
									build.append("\n");
									
								}
								
								FileWriter fw = new FileWriter("file1.csv");
								BufferedWriter bw = new BufferedWriter(fw);
								
								bw.write(build.toString());
								bw.close();
								
								System.out.println("Contact has been deleted. Returning to menu\n");
								MenuOption();
								
							}
							//Return to menu
							else if (ask1.equals("2")) {
								System.out.println("Returning to menu\n");
								MenuOption();
							}
						}
					}
				}
			}
			
			
			catch (IOException e) {
				e.printStackTrace();
			}
	}
		else {
			System.out.println("There are 0 saved contacts. Returning to menu.");
			MenuOption();
		}
	}
	
	// Counter to count the number of entries in the file
	private static int counter() {
		
		int lines = 1;
		
		try {
			
			FileReader fr = new FileReader("file1.csv");
			BufferedReader br = new BufferedReader(fr);
			Scanner read = new Scanner(br);
			
			while (read.hasNextLine()) {
				
				read.nextLine();
				lines++;
				
			}
			
			fr.close();
			br.close();
			read.close();
						
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return lines;
		}
	
	private static void editContact() {
		
		Scanner scan = new Scanner(System.in);
		System.out.printf("%n%s%n%s%n", "Search for the contact", "Either enter All or a particular letter:");
		String pick = scan.next();
		
		//Search for contact
		try {
			
			FileReader fr = new FileReader("file1.csv");
			BufferedReader br = new BufferedReader(fr);
			Scanner read = new Scanner(br);
			
			FileReader fr2 = new FileReader("file1.csv");
			BufferedReader br2 = new BufferedReader(fr2);
			Scanner read2 = new Scanner(br2);
			
			if (counter() > 1) {
				//All
				if (pick.equals("All") || pick.equals("all")) {
				
					while (read.hasNext()) {
						int count = read.nextInt();
						String firstName = read.next();
						String lastName = read.next();
						String number = read.next();
						System.out.printf("%-5s %-10s %-10s %-10s%n", count, firstName, lastName, number);
					}	
				}
				//Particular Letter
				else if (alphabet(pick)) {
				
					while (read.hasNext()) {
						char p = pick.charAt(0);
						int count = read.nextInt();
						String firstName = read.next();
						String lastName = read.next();
						String number = read.next();
						char letter = firstName.charAt(0);
						if (letter == Character.toLowerCase(p) || letter == Character.toUpperCase(p)) {
							System.out.printf("%-5s %-10s %-10s %-10s%n", count, firstName, lastName, number);
						}
					}
				}
				
				System.out.printf("%n%s%n", "Select the number of the contact that you wish to edit:");
				String entry = scan.next();
				
				while(read2.hasNext()) {
					
					String count = read2.next();
					String firstName = read2.next();
					String lastName = read2.next();
					String number = read2.next();
					
					if (entry.equals(count)) {
						
						System.out.printf("%n%s%n%n%-5s %-5s %-5s%n%n%s%n%s%n", "Is this the contact you wish to edit?:", firstName, 
								lastName, number, "1 - Edit", "2 - Return to menu");
						String ask1 = scan.next();
						//Edit
						if (ask1.equals("1")) {
							
							String ask2 = "2";
							//Edit again cycle
							while (ask2.equals("2")) {
								
								System.out.println("New first name:");
								String newFirstName = scan.next();
								System.out.println("New last name:");
								String newLastName = scan.next();
								System.out.println("New Number:");
								String newNumber = scan.next();
								
								System.out.printf("%n%s%n%-10s%-10s%-10s%n%n%s%n%s%n%s%n", "Are you happy with your changes?", 
										newFirstName, newLastName, newNumber, "1 - Save changes", "2 - Edit again",
										"3 - Discard changes");
								ask2 = scan.next();	
								//Save changes
								if (ask2.equals("1")) {
									
									int entryInt = Integer.parseInt(entry) - 1;
									LinkedList<String> links = entriesToString();
									StringBuilder build = new StringBuilder();
									
									links.remove(entryInt);
									String newEntry = Integer.parseInt(entry) + " " + newFirstName + " " + newLastName
											+ " " + newNumber;
									links.add(entryInt, newEntry);
																		
									for (String link : links) {
										
										build.append(link);
										build.append("\n");
										
									}
									
									FileWriter fw = new FileWriter("file1.csv");
									BufferedWriter bw = new BufferedWriter(fw);
									
									bw.write(build.toString());
									bw.close();

									System.out.println("Changes have been saved. Returning to menu\n");
									MenuOption();
									
								}
							}
							//Discard Changes
							if (ask2.equals("3")) {
								
								System.out.println("Discarding changes. Returning to menu\n");
								MenuOption();
							}
							
						}
						//Return to Menu without editing
						else if (ask1.equals("2")) {
							System.out.println("Returning to menu\n");
							MenuOption();
						}
					}
				}
			}
			
			else {
				System.out.printf("%n%s%n", "There are 0 saved contacts. Returning to menu...");
				MenuOption();
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

		
	}
	
	private void orderContactsAlphabetically() {
		
		/* Read text files. Add each entry to a List
		 * Order the list alphabetically
		 * Write the ordered list to the file
		 */
		
	}
	
	//Sub method for EditContact. Reads texts file, file1.txt, converts it to list, returns list.
	//Might use for DeleteContact
	private static LinkedList<String> entriesToString() {
		
		LinkedList<String> links = new LinkedList<>();
		
		try {
			
			FileReader fr = new FileReader("file1.csv");
			BufferedReader br = new BufferedReader(fr);
			Scanner read = new Scanner(br);
			
			while (read.hasNext()) {
				
				String line = read.nextLine();
				links.add(line);
				
			}
			
		} catch (FileNotFoundException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return links;
	}
				
}

// Create file, if one does not already exist
// Method for ordering entries alphabetically
