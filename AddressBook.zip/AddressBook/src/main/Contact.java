package main;

public class Contact {

	private String firstName;
	private String lastName;
	private String Number;
	
	Contact(String firstName, String lastName, String Number) {
		
		this.firstName = firstName;
		this.lastName = lastName;
		this.Number = Number;
	}
	
	public String getfirstName() {
		return firstName;
	}
	
	public String getlastName() {
		return lastName;
	}
	
	public String getNumber() {
		return Number;
	}
	
	public void setfirstName() {
		this.firstName = firstName;
	}
	
	public void setlastName() {
		this.lastName = lastName;
	}
	
	public void setNumber() {
		this.Number = Number;
	}
	
	@Override
	public String toString() {
		return String.format("%-10s%s %s%n%-10s%-10s%n", "Name: ", firstName, lastName, "Number: ", Number);
	}
	
}
