// Enum type for CreditInquiry program
public enum MenuOption {
	
	//Entering elements into Enum, like an array
	Zero_Balance(1),
	Credit_Balance(2),
	Debit_Balance(3),
	Exit(4);
	
	private final int value; //Menu option index
	
	// Constructor
	private MenuOption(int value) {
		this.value = value;
	}

}
