import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class BinarySearchTest {

//	public static void main(String[] args) {
		String[] colours = {"Red", "Yellow", "Blue", "Green", "Purple", "Orange", "Tan", "Black"};
		List<String> list = new ArrayList<>(Arrays.asList(colours));
		
		Collections.sort(list);
		System.out.printf("Sorted ArrayList: %s%n", list);
		
		printSearchResults(list, "Black");
		printSearchResults(list, "Blue");
		printSearchResults(list, "Yellow");
		printSearchResults(list, "Gold");
		printSearchResults(list, "Asian");

	}
	
	private static void printSearchResults(List<String> list, String key) {
		
		int result = 0;
		result = Collections.binarySearch(list, key);
		
		System.out.printf("%nSearching for: %s%n", key);
		if (result >= 0) {
			System.out.printf("Found at position %d%n", result);
		} else {
			System.out.println("No Match");
		}
		
	}

}
