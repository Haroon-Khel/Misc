//HashSets are sets of data that contain no duplicate values.

import java.util.List;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.Collections;

public class SetTest {

	public static void main(String[] args) {
		
		//Create a String array, and convert it into a List
		String[] colours = {"Red", "White", "Blue", "Green", "Gray", "Orange", "Tan", "White", "Cyan", "Peach", "Gray", "Orange"};
		List<String> list = Arrays.asList(colours);
		
		System.out.printf("List: %s%n", list);
		
		printNonDuplicate(list);
		
	}
	
	//Method to eliminate duplicates from the List by turning it into a HashSet
	private static void printNonDuplicate(Collection<String> values) {
		
		Set<String> set = new HashSet<>(values);
		System.out.printf("%nNon Duplicates are: ");
		
		for (String value : set) {
			
			System.out.printf("%s ", value);
			
		}
		System.out.println();
		
	}

}
