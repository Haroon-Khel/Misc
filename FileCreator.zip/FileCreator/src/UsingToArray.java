import java.awt.List;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;

public class UsingToArray {

	public static void main(String[] args) {
	
		String[] colours = {"Black", "Blue", "Yellow"};
		LinkedList<String> links = new LinkedList<>(Arrays.asList(colours));
		
		links.addLast("Red");
		links.add("Pink");
		links.add(3, "Rouge");
		links.addFirst("White");
		
		colours = links.toArray(new String[links.size()]);
		System.out.println("Colours: ");
		
		for (String colour : colours) {
			System.out.println(colour);
		}
		
		System.out.println(links);
		
		String[] suits = {"Diamonds", "Clubs", "Spades", "Hearts"};
		
		LinkedList<String> links2 = new LinkedList<>(Arrays.asList(suits));
		
		System.out.println("%nUnsorted elements in suits list:%n" + links2);
		Collections.sort(links2);
		System.out.println("%nSuits list, after sort method:%n" + links2);

	}

}
