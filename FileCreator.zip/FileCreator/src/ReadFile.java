import java.io.IOException;
import java.lang.IllegalStateException;
import java.nio.file.Paths;
import java.util.NoSuchElementException;
import java.util.Scanner;


public class ReadFile {
	
	private static Scanner input; // Scanner object to read file information

	//public static void main(String[] args) {
		
		CreateTextFile.openFile();
		CreateTextFile.addRecords();
		CreateTextFile.closeFile();
		openFile(); //Open file on disk
		readRecords(); // Read the file while its open
		closeFile(); // Close file when no longer needed
		

//	}
	
	public static void openFile() {
		
		try {
			input = new Scanner(Paths.get("clients.txt")); // Scanner constructor takes a path as a parameter. Paths.get gets the path of the
			// clients.txt file
		}
		
		catch (IOException ioException) { // Errors associated with opening file
			System.err.println("Error opening file. Terminating");
			System.exit(1);
		}
		
	}
	
	public static void readRecords() {
		
		System.out.printf("%n%-10s%-12s%-12s%10s%n", "Account", "First Name", "Last Name", "Balance");
		
		try {
			while (input.hasNext()) { // Will terminate at the bottom of the file, as there will be no more input to be read
				
				System.out.printf("%-10s%-12s%-12s%10s%n", input.nextInt(), input.next(), input.next(), input.nextDouble());
				// Scanner is expecting to read one integer, two strings and one double, else exceptions occur
			}			
		}
		
		catch (NoSuchElementException noSuchElementException) {// If the elements in file are not laid out in the desired format
			System.err.println("File improperly formed. Terminating");
		}
		
		catch (IllegalStateException stateException) { //If Scanner object is closed before information is read
			System.err.println("Error reading from file. Terminating");
		}

		
	}
	
	public static void closeFile() { // Method to close file
		
		if (input != null) {
			input.close();
		}
		
	}

}
