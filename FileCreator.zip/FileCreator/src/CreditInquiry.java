//This class reads files sequentially and displays info corresponding to the chosen menu option
import java.io.IOException;
import java.lang.IllegalStateException;
import java.nio.file.Paths;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class CreditInquiry {
	
	private static final MenuOption[] choices = MenuOption.values(); //Creating a MenuOption object 

//	public static void main(String[] args) {
		
		// Get users request
		MenuOption accountType = getRequest(); //getRequest returns an element of the MenuOption Enum, while displaying the menu screen
		
		while (accountType != MenuOption.Exit) { //While loop to prompt user for menu option
			
			switch(accountType) {
			
			case Zero_Balance:
				System.out.printf("%nAccounts with Zero Balance:%n");
				break;
			case Credit_Balance:
				System.out.printf("%nAccounts with Credit Balance:%n");
				break;
			case Debit_Balance:
				System.out.printf("%nAccounts with Debit Balance:%n");
				break;
						
			}
			
			readRecords(accountType); // Displays the account information corresponding to the menu option chosen
			accountType = getRequest(); // Prompts the user to input another menu option, rinse and repeat
		}
		

	}
	
	private static MenuOption getRequest() { //Returns a result of type: MenuOption, in this case an element of the MenuOption enum
		
		int request = 4;
		
		//Display request options:
		System.out.printf("%nEnter Request:%n%s%n%s%n%s%n%s", 
				"1 - Accounts with Zero Balance",
				"2 - Accounts with Credit Balance",
				"3 - Accounts with Debit Balance",
				"4 - Terminates Request");
		
		try  { //Do..While statement which loops until user has inputed a number between 1 and 4
			Scanner input = new Scanner(System.in);
			
			do {
				System.out.printf("%n>>");
				request = input.nextInt();
			} while ((request<1 || request>4));
		}
		
		catch (NoSuchElementException noSuch) {
			System.err.println("Invalid Input. Terminating"); // A catch for invalid "Type" input
		}
		
		return choices[request - 1]; //Returns the desired element of the MenuOption Enum, in this case, from an object of that Enum
		
		
	}
	// Read records from file and only display appropriate statements
	private static void readRecords(MenuOption accountType) {
		// Try block with parameter of an object used only for the try block
		try (Scanner input = new Scanner(Paths.get("clients.txt"))) { //Opens up a stream to the file
			
			while (input.hasNext()) { //While the scanner is still able to read the file or while there is more info to read
				// Make the following assignments:
				int accountNumber = input.nextInt();
				String firstName = input.next();
				String lastName = input.next();
				double balance = input.nextDouble();
				
				if (shouldDisplay(accountType, balance)) { //If true, ie if the read line matches the desired input, then
					// that line will be displayed. Because of the while statement + the input.nextLine() method, this will
					//look through each line of the clients file
					System.out.printf("%-10d%-12s%-12s%-10.2f%n", accountNumber, firstName,
							lastName, balance);
				} else {
					input.nextLine(); //If no such match is made, advance to the next line
				}
				
			}
			
		}
		
		catch (NoSuchElementException | IllegalStateException | IOException e) {
			System.err.println("Error processing the file. Terminating");
			System.exit(1);
		}		
	}
	
	//Method that returns true only when, when reading through the file, reads an entry with the appropriate
	//Account type and corresponding balance. If it returns true on such a line, then that line will be displayed.
	private static boolean shouldDisplay(MenuOption accountType, double balance) {
		
		if ((accountType == MenuOption.Credit_Balance) && (balance < 0)) {
			return true;
		}
		else if ((accountType == MenuOption.Debit_Balance) && (balance > 0)) {
			return true;
		}
		else if ((accountType == MenuOption.Zero_Balance) && (balance == 0)) {
			return true;
		}
		
		return false;
		
	}

}
