import java.io.FileNotFoundException;
import java.util.Formatter;
import java.util.FormatterClosedException;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.lang.SecurityException;

public class CreateTextFile {
	
	private static Formatter output;

	//public static void main(String[] args) {
		
	//	openFile();
//		addRecords();
//		closeFile();

//	}
	
	public static void openFile() {
		
		try {
			output = new Formatter("clients.txt"); //Input parameter for creating a formatter object is simply the name of the file
		} // No absolute path specified, thus the file will be created in the current folder
		
		catch (SecurityException securityException) { // Usually occurs when trying to write into file without appropriate security privileges
			System.err.println("Write permission denied. Terminating");
			System.exit(1); //Terminates the program
		}
		
		catch (FileNotFoundException fileNotFoundException) { // Usually occurs due to errors associated with file creation
			System.err.println("Error opening the file. Terminating");
			System.exit(1);
		}
		
	}
	
	public static void addRecords() {
		
		Scanner input = new Scanner(System.in);
		System.out.printf("%s%n%s%n", "Enter account number, first name, last name and balance", 
				"Enter End of file indicator to end input");
		
		while (input.hasNext()) { //.hasNext returns true as long as the EOF indicator has not been entered
			
			try {
				
				// Output is our formatter object. The format method adds its parameters, in our case user input, to the file
				output.format("%d %s %s %.2f%n", input.nextInt(), input.next(), input.next(), input.nextDouble());
				
			}
			
			catch (FormatterClosedException formatterClosedException) {
				System.err.println("Error writing to file. Terminating");
				break;
			}
			
			catch (NoSuchElementException noSuchElementException) {
				System.err.println("Invalid input. Try again");
				input.nextLine();
			}
			
			System.out.print("? "); //This will precede user input
			
			
		}
		
	}
	
	public static void closeFile() {
		
		if (output != null) {
			output.close(); //Closes an open format object. Closes the file on disk
		}
		
	}
	

}
